'use strict';

const property_registration  = require('./userContract.js');
module.exports.contracts = [property_registration];

const property_registration  = require('./registrarContract.js');
module.exports.contracts = [property_registration];
