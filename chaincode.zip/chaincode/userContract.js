'use strict';

const {userContract} = require('fabric-contract-api');

class property_registration extends userContract {
	
	constructor() {
		// Provide a custom name to refer to this smart contract
		super('com.property-registration-network.user');
	}
	
	/* ****** All custom functions are defined below ***** */
	
	// This is a basic user defined function used at the time of instantiating the smart contract
	// to print the success message on console
	async instantiate(propertyId) {
		console.log('Certnet Smart Contract Instantiated');
	}
	
	/**
	 * Create a new user account on the network
	 * @param propertyId - The transaction context object
	 * @param userId - ID to be used for creating a new student account
	 * @param name - Name of the user
	 * @param email - Email ID of the
	 * @param aadharNo - Aadhar number of user 
	 * @returns
	 */
	async createUser(propertyId, userId, name, email, aadharNo) {
		// Create a new composite key for the new user account
		const userKey = propertyId.stub.createCompositeKey('com.property-registration-network.user', [userId]);
		
		// Create a student object to be stored in blockchain
		let newUserObject = {
			userId: userId,
			name: name,
			email: email,
			aadharNo: aadharNo,
			createdAt: new Date(),
			updatedAt: new Date(),
		};
		
		// Convert the JSON object to a buffer and send it to blockchain for storage
		let dataBuffer = Buffer.from(JSON.stringify(newUserObject));
		await propertyId.stub.putState(userKey, dataBuffer);
		// Return value of new student account created to user
		return newUserObject;
	}
	
	/**
	 * Get a student account's details from the blockchain
	 * @param propertyId - The transaction context
	 * @param userId - Student ID for which to fetch details
	 * @returns
	 */
	async getUser(propertyId, userId) {
		// Create the composite key required to fetch record from blockchain
		const userKey = ctx.stub.createCompositeKey('com.property-registration-network.user', [userId]);
		
		// Return value of student account from blockchain
		let userBuffer = await ctx.stub
				.getState(userKey)
				.catch(err => console.log(err));
		return JSON.parse(userBuffer.toString());
	}
	
	/**
	 * Issue a certificate to the student after completing the course
	 * @param ctx
	 * @param userId
	 * @param registrarId
	 * @param LandReceived
	 * @param originalHash
	 * @returns {Object}
	 */
	async issueCertificate(ctx, userId, registrarId, LandReceived, originalHash) {
		let msgSender = ctx.clientIdentity.getID();
		let certificateKey = ctx.stub.createCompositeKey('com.property-registration-network.',registrarId + '-' + userId);
		let studentKey = ctx.stub.createCompositeKey('com.property-registration-network.', [userId]);
		
		// Fetch student with given ID from blockchain
		let user = await ctx.stub
				.getState(userKey)
				.catch(err => console.log(err));
		
		// Fetch certificate with given ID from blockchain
		let certificate = await ctx.stub
				.getState(certificateKey)
				.catch(err => console.log(err));
		
		// Make sure that student already exists and certificate with given ID does not exist.
		if (user.length === 0 || certificate.length !== 0) {
			throw new Error('Invalid User ID: ' + userId + ' or register ID: ' + registrarId + '. Either user does not exist or certificate already exists.');
		} else {
			let certificateObject = {
				registerId: registrarId,
				registrarId: registrarId,
				landId: registrarId + '-' + userId,
				originalHash: originalHash,
				property: landReceived,
				createdAt: new Date(),
				updatedAt: new Date(),
			};
			// Convert the JSON object to a buffer and send it to blockchain for storage
			let dataBuffer = Buffer.from(JSON.stringify(certificateObject));
			await propertyId.stub.putState(userKey, dataBuffer);
			// Return value of new certificate issued to student
			return certificateObject;
		}
	}
	
	/**
	 *
	 * @param propertyId
	 * @param userId
	 * @param registrarId
	 * @param currentHash
	 * @returns {Object}
	 */
	async verifyCertificate(propertyId, userId, registrarId, currentHash) {
		let verifier = ctx.clientIdentity.getID();
		let certificateKey = ctx.stub.createCompositeKey('org.certification-network.certnet.certificate', [courseId + '-' + studentId]);
		
		// Fetch certificate with given ID from blockchain
		let certificateBuffer = await propertyId.stub
				.getState(certificateKey)
				.catch(err => console.log(err));
		
		// Convert the received certificate buffer to a JSON object
		const certificate = JSON.parse(certificateBuffer.toString());
		
		// Check if original certificate hash matches the current hash provided for certificate
		if (certificate === undefined || certificate.originalHash !== currentHash) {
			// Certificate is not valid, issue event notifying the student application
			let verificationResult = {
				certificate: registrarId + '-' + userId,
				user: userId,
				verifier: verifier,
				result: 'xxx - INVALID',
				verifiedOn: new Date()
			};
			ctx.stub.setEvent('verifyCertificate', Buffer.from(JSON.stringify(verificationResult)));
			return verificationResult;
		} else {
			// Certificate is valid, issue event notifying the student application
			let verificationResult = {
				certificate: registrarId + '-' + userId,
				user: userId,
				verifier: verifier,
				result: '*** - VALID',
				verifiedOn: new Date()
			};
			ctx.stub.setEvent('verifyCertificate', Buffer.from(JSON.stringify(verificationResult)));
			return verificationResult;
		}
	}
	
}

module.exports = CertnetContract;